-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 09-11-2026 a las 02:19:45
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `bd`
--
CREATE DATABASE IF NOT EXISTS `bd` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `bd`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `administrativos`
--

CREATE TABLE `administrativos` (
  `usuario` varchar(20) NOT NULL,
  `NombreCompleto` varchar(30) NOT NULL,
  `Contraseña` varchar(20) NOT NULL,
  `CorreoElectronico` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `administrativos`
--

INSERT INTO `administrativos` (`usuario`, `NombreCompleto`, `Contraseña`, `CorreoElectronico`) VALUES
('damian', 'Damian Urriaga', 'damian321', 'damianmartinez@gmail.com'),
('diana', 'Diana Diaz', '@Diaz_02', 'dianitadiaz@gmail.com'),
('martin', 'Martin Gonzalez', 'gonza229', 'gonzalezmartin@gmail.com');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `idcategoria` int(10) NOT NULL,
  `nombre` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`idcategoria`, `nombre`) VALUES
(101010104, 'Categoria 1'),
(101010105, 'Categoria 2'),
(101010106, 'Categoria 3');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `documentos`
--

CREATE TABLE `documentos` (
  `iddocumentos` int(10) NOT NULL,
  `titulo` varchar(20) NOT NULL,
  `informacion` varchar(10000) NOT NULL,
  `qr` varchar(64) NOT NULL,
  `usuario` varchar(20) NOT NULL,
  `FechaCreacion` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `documentos`
--

INSERT INTO `documentos` (`iddocumentos`, `titulo`, `informacion`, `qr`, `usuario`, `FechaCreacion`) VALUES
(45, 'Ejemplo 1', 'Este documento de ejemplo se ha abierto correctamente', 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=ht', 'diana', '2026-11-09'),
(46, 'Ejemplo 2', 'Si se ha abierto este documento, quiere decir que funciona este tambien', 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=ht', 'martin', '2026-11-09'),
(47, 'Ejemplo 3', 'Este documento comprueba si los caracteres especiales no alteran la funcionalidad de la pagina ¨*][_:;¡?=)(/&%$#\"!´+}{-.,¿\'0987654321', 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=ht', 'damian', '2026-11-09');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `documento_categoria`
--

CREATE TABLE `documento_categoria` (
  `iddocumentos` int(10) NOT NULL,
  `idcategoria` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `documento_categoria`
--

INSERT INTO `documento_categoria` (`iddocumentos`, `idcategoria`) VALUES
(45, 101010104),
(46, 101010105),
(47, 101010104);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `elementos`
--

CREATE TABLE `elementos` (
  `idelemento` int(10) NOT NULL,
  `tipo` varchar(20) NOT NULL,
  `cantidad` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `encuestas`
--

CREATE TABLE `encuestas` (
  `idencuesta` int(10) NOT NULL,
  `tipo` varchar(15) NOT NULL,
  `Usuario` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `encuesta_pregunta`
--

CREATE TABLE `encuesta_pregunta` (
  `idencuesta` int(10) NOT NULL,
  `idpregunta` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `medicos`
--

CREATE TABLE `medicos` (
  `ci` int(10) NOT NULL,
  `nombrecompleto` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modifican`
--

CREATE TABLE `modifican` (
  `usuario` varchar(20) NOT NULL,
  `iddocumentos` int(10) NOT NULL,
  `fecha` date NOT NULL,
  `responsable` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pacientes`
--

CREATE TABLE `pacientes` (
  `ci` int(10) NOT NULL,
  `estado` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `preguntas`
--

CREATE TABLE `preguntas` (
  `Idpregunta` int(10) NOT NULL,
  `Texto` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `respuestas`
--

CREATE TABLE `respuestas` (
  `Idpregunta` int(10) NOT NULL,
  `FechaRes` date NOT NULL,
  `Valorizacion` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `telefono_administrativo`
--

CREATE TABLE `telefono_administrativo` (
  `Usuario` varchar(20) NOT NULL,
  `telefono` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `telefono_medicos`
--

CREATE TABLE `telefono_medicos` (
  `ci` int(10) NOT NULL,
  `telefono` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `traslados`
--

CREATE TABLE `traslados` (
  `idtraslado` int(10) NOT NULL,
  `fechatraslado` date NOT NULL,
  `tipo` varchar(100) NOT NULL,
  `texto` varchar(100) NOT NULL,
  `estado` varchar(100) NOT NULL,
  `destino` varchar(50) NOT NULL,
  `ci_medico` int(10) NOT NULL,
  `matricula` varchar(7) NOT NULL,
  `ci_acompañante` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `traslado_paciente`
--

CREATE TABLE `traslado_paciente` (
  `idtraslado` int(11) NOT NULL,
  `ci_paciente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vehiculo_chofer`
--

CREATE TABLE `vehiculo_chofer` (
  `matricula` varchar(7) NOT NULL,
  `ci` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `administrativos`
--
ALTER TABLE `administrativos`
  ADD PRIMARY KEY (`usuario`);

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`idcategoria`);

--
-- Indices de la tabla `documentos`
--
ALTER TABLE `documentos`
  ADD PRIMARY KEY (`iddocumentos`),
  ADD KEY `usuario` (`usuario`);

--
-- Indices de la tabla `documento_categoria`
--
ALTER TABLE `documento_categoria`
  ADD PRIMARY KEY (`iddocumentos`,`idcategoria`),
  ADD KEY `idcategoria` (`idcategoria`);

--
-- Indices de la tabla `elementos`
--
ALTER TABLE `elementos`
  ADD PRIMARY KEY (`idelemento`);

--
-- Indices de la tabla `encuestas`
--
ALTER TABLE `encuestas`
  ADD PRIMARY KEY (`idencuesta`),
  ADD KEY `Usuario` (`Usuario`);

--
-- Indices de la tabla `encuesta_pregunta`
--
ALTER TABLE `encuesta_pregunta`
  ADD PRIMARY KEY (`idencuesta`,`idpregunta`),
  ADD KEY `idencuesta` (`idencuesta`),
  ADD KEY `idpregunta` (`idpregunta`);

--
-- Indices de la tabla `medicos`
--
ALTER TABLE `medicos`
  ADD PRIMARY KEY (`ci`),
  ADD KEY `ci` (`ci`),
  ADD KEY `ci_2` (`ci`);

--
-- Indices de la tabla `modifican`
--
ALTER TABLE `modifican`
  ADD PRIMARY KEY (`usuario`),
  ADD KEY `iddocumentos` (`iddocumentos`);

--
-- Indices de la tabla `pacientes`
--
ALTER TABLE `pacientes`
  ADD PRIMARY KEY (`ci`);

--
-- Indices de la tabla `preguntas`
--
ALTER TABLE `preguntas`
  ADD PRIMARY KEY (`Idpregunta`),
  ADD KEY `Idpregunta` (`Idpregunta`),
  ADD KEY `Idpregunta_2` (`Idpregunta`);

--
-- Indices de la tabla `respuestas`
--
ALTER TABLE `respuestas`
  ADD PRIMARY KEY (`Idpregunta`),
  ADD KEY `Idpregunta` (`Idpregunta`);

--
-- Indices de la tabla `telefono_administrativo`
--
ALTER TABLE `telefono_administrativo`
  ADD PRIMARY KEY (`Usuario`);

--
-- Indices de la tabla `telefono_medicos`
--
ALTER TABLE `telefono_medicos`
  ADD PRIMARY KEY (`ci`,`telefono`);

--
-- Indices de la tabla `traslados`
--
ALTER TABLE `traslados`
  ADD PRIMARY KEY (`idtraslado`),
  ADD KEY `ci_medico` (`ci_medico`),
  ADD KEY `matricula` (`matricula`);

--
-- Indices de la tabla `traslado_paciente`
--
ALTER TABLE `traslado_paciente`
  ADD PRIMARY KEY (`idtraslado`),
  ADD KEY `ci_paciente` (`ci_paciente`);

--
-- Indices de la tabla `vehiculo_chofer`
--
ALTER TABLE `vehiculo_chofer`
  ADD PRIMARY KEY (`matricula`,`ci`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `idcategoria` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101010107;

--
-- AUTO_INCREMENT de la tabla `documentos`
--
ALTER TABLE `documentos`
  MODIFY `iddocumentos` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `documentos`
--
ALTER TABLE `documentos`
  ADD CONSTRAINT `documentos_ibfk_1` FOREIGN KEY (`usuario`) REFERENCES `administrativos` (`usuario`);

--
-- Filtros para la tabla `documento_categoria`
--
ALTER TABLE `documento_categoria`
  ADD CONSTRAINT `documento_categoria_ibfk_1` FOREIGN KEY (`iddocumentos`) REFERENCES `documentos` (`iddocumentos`),
  ADD CONSTRAINT `documento_categoria_ibfk_2` FOREIGN KEY (`idcategoria`) REFERENCES `categorias` (`idcategoria`);

--
-- Filtros para la tabla `encuestas`
--
ALTER TABLE `encuestas`
  ADD CONSTRAINT `encuestas_ibfk_1` FOREIGN KEY (`Usuario`) REFERENCES `administrativos` (`usuario`);

--
-- Filtros para la tabla `encuesta_pregunta`
--
ALTER TABLE `encuesta_pregunta`
  ADD CONSTRAINT `encuesta_pregunta_ibfk_1` FOREIGN KEY (`idencuesta`) REFERENCES `encuestas` (`idencuesta`),
  ADD CONSTRAINT `encuesta_pregunta_ibfk_2` FOREIGN KEY (`idpregunta`) REFERENCES `preguntas` (`Idpregunta`);

--
-- Filtros para la tabla `modifican`
--
ALTER TABLE `modifican`
  ADD CONSTRAINT `modifican_ibfk_1` FOREIGN KEY (`usuario`) REFERENCES `administrativos` (`usuario`),
  ADD CONSTRAINT `modifican_ibfk_2` FOREIGN KEY (`iddocumentos`) REFERENCES `documentos` (`iddocumentos`);

--
-- Filtros para la tabla `respuestas`
--
ALTER TABLE `respuestas`
  ADD CONSTRAINT `respuestas_ibfk_1` FOREIGN KEY (`Idpregunta`) REFERENCES `preguntas` (`Idpregunta`);

--
-- Filtros para la tabla `telefono_administrativo`
--
ALTER TABLE `telefono_administrativo`
  ADD CONSTRAINT `telefono_administrativo_ibfk_1` FOREIGN KEY (`Usuario`) REFERENCES `administrativos` (`usuario`);

--
-- Filtros para la tabla `telefono_medicos`
--
ALTER TABLE `telefono_medicos`
  ADD CONSTRAINT `telefono_medicos_ibfk_1` FOREIGN KEY (`ci`) REFERENCES `medicos` (`ci`);

--
-- Filtros para la tabla `traslados`
--
ALTER TABLE `traslados`
  ADD CONSTRAINT `traslados_ibfk_1` FOREIGN KEY (`ci_medico`) REFERENCES `medicos` (`ci`),
  ADD CONSTRAINT `traslados_ibfk_2` FOREIGN KEY (`matricula`) REFERENCES `vehiculo_chofer` (`matricula`);

--
-- Filtros para la tabla `traslado_paciente`
--
ALTER TABLE `traslado_paciente`
  ADD CONSTRAINT `traslado_paciente_ibfk_1` FOREIGN KEY (`ci_paciente`) REFERENCES `pacientes` (`ci`),
  ADD CONSTRAINT `traslado_paciente_ibfk_2` FOREIGN KEY (`idtraslado`) REFERENCES `traslados` (`idtraslado`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
