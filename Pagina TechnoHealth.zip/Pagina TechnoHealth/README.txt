# README - Documentación del proyecto

En esta última entrega del proyecto *TechnoHealth* se incorporaron las funcionalidades finales de la página.
La mayor parte del sistema se encuentra completa y funcional, permitiendo que los usuarios puedan utilizarlo con comodidad.

# Funciones principales del sistema

- Iniciar sesión.
- Verificar a los usuarios al acceder a cada página.
- Gestionar documentos.
- Agregar documentos.
- Eliminar documentos.
- Modificar documentos.
- Crear categorías.
- Eliminar categorías.
- Filtrar documentos por categorías.
- Acceder a la documentación mediante códigos QR.
- Gestionar encuestas.
- Cerrar sesión.

# Instalación y configuración

Para poder utilizar el sistema, primero se deben realizar las siguientes instalaciones y configuraciones:

- Instalar XAMPP 3.3.0.
- MySQL (incluido en XAMPP).
- Apache (incluido en XAMPP).
- Una vez instalado XAMPP, abrir XAMPP Control Panel.
- Iniciar los servicios de Apache y MySQL.
- Hacer clic en el botón «Admin» de MySQL o escribir `localhost/phpmyadmin` en el navegador.
- Una vez dentro de phpMyAdmin, seleccionar el apartado «Importar», ubicado en la barra superior.
- Seleccionar el archivo `bd.sql`, ubicado dentro de la carpeta de la base de datos, e importarlo.
- Finalmente, copiar todos los archivos del proyecto con extensión `.html`, `.css` y `.php` a la carpeta `htdocs`,
ubicada normalmente en la ruta `C:\xampp\htdocs`.

Una vez completados los pasos anteriores, el sistema estará listo para utilizarse. A continuación, se explicará su funcionamiento.

# Uso del sistema

- Para ingresar a la aplicación, se deberá escribir `localhost/Index.html` en la barra de direcciones del navegador.
- Una vez dentro, aparecerá un menú en el que se solicitarán al usuario su nombre de usuario y contraseña.

# Usuarios de prueba

Los usuarios de prueba registrados en la base de datos son los siguientes:
Usuario: damian
Contraseña: damian321

Usuario: diana
Contraseña: @Diaz_02

Usuario: martin
Contraseña: gonza229

# Iniciar sesión

- Esta página está vinculada con todas las secciones del sistema.
Como medida de seguridad, no se podrá acceder a ninguna página que permita modificar datos sin haber iniciado sesión.
- Si se intenta acceder a alguna de estas páginas sin haber iniciado sesión, el usuario será redirigido automáticamente a `Index.html` para identificarse.
- Luego de ingresar los datos de uno de los usuarios y hacer clic en el botón «Iniciar sesión», si las credenciales son correctas,
el usuario será redirigido automáticamente al apartado `Administracion.php`.

# Administración

- Dentro de esta sección se encuentran la mayoría de las funcionalidades del sistema.
- Se podrán visualizar los documentos almacenados en la base de datos.
- También se mostrarán los usuarios que crearon o modificaron los documentos, sus respectivas fechas,
el código QR asignado a cada documento y la opción de descargarlo.
- Se podrán filtrar los documentos según las categorías almacenadas en la base de datos.
- Cada uno de los botones disponibles se explicará en los siguientes apartados del README.

# Crear documentos

- Se deberá ingresar el título del documento.
- Se deberá ingresar el contenido del documento.
- Se deberá asignar la categoría correspondiente.
- Al subir el documento, se guardarán automáticamente el usuario que lo creó, la fecha de creación o modificación y
se generará un código QR para que los pacientes puedan acceder a él.
- El sistema no permitirá subir un documento si no se han completado los campos del título y del contenido.

# Modificar documentos

- Aparecerán los campos completados con la información que contenía el documento seleccionado.
- También aparecerá un campo adicional correspondiente al ID del documento, el cual no podrá modificarse.
- El resto de los campos serán iguales a los de la sección «Crear documentos».
- Al guardar los cambios, se actualizarán automáticamente el usuario que modificó el documento y la fecha de modificación.

# Borrar documentos

- Al presionar el botón correspondiente, se solicitará una confirmación al usuario antes de eliminar el documento.
- Una vez confirmada la acción, el documento se eliminará automáticamente.

# Crear categoría

- Aparecerá un menú breve en el que se solicitará el nombre de la categoría.
- El sistema no permitirá crear una categoría si no se le asigna un nombre.
- Una vez creada, la categoría aparecerá en el apartado «Filtrar por categoría».

# Borrar categoría

- Aparecerá un menú en el que se solicitará al usuario seleccionar la categoría que desea eliminar.
- No se podrá eliminar ninguna categoría si no se selecciona una previamente.

# Filtrar por categoría

- Aparecerá un menú desplegable con todas las categorías creadas y una opción que siempre estará disponible: «Todas las categorías».
- Al seleccionar una categoría, solo se mostraran los documentos relacionados a la categoría especificada.

# Ver documento

- Para ingresar a un documento y consultar su información, solo será necesario hacer clic en el documento correspondiente.
- Se mostrarán los mismos datos del documento, pero de una manera más detallada y completa.
- Debajo del contenido aparecerá un botón que permitirá volver a la pestaña de Administración.
- Los pacientes también podrán acceder al documento correspondiente mediante el código QR.

# Cerrar sesión

- En la parte superior derecha de la página se podrá visualizar el usuario activo y un botón para cerrar sesión.
- Al hacer clic en dicho botón, la sesión se cerrará y el usuario será redirigido a `Index.html`, donde se le volverán a solicitar su nombre de usuario y contraseña.

# Encuestas

- Este apartado contiene únicamente el diseño de la sección, ya que no se pudo completar su implementación.
- El único botón funcional es el de «Terminar encuesta», que redirige al usuario a `Administracion.php`.