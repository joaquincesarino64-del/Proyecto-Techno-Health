
<?php
session_start();

// Verificar que se hayan enviado los datos
if (
    !isset($_POST['usuario'], $_POST['Contraseña']) ||
    trim($_POST['usuario']) === '' ||
    $_POST['Contraseña'] === ''
) {
    header("Location: Index.html?error=1");
    exit();
}

$usuario = trim($_POST['usuario']);
$contrasena = $_POST['Contraseña'];

include('bd.php');

// Buscar al usuario en la base de datos
$sql = "SELECT usuario
        FROM administrativos
        WHERE usuario = ? AND Contraseña = ?";

$sentencia = $conexion->prepare($sql);

if (!$sentencia) {
    exit("Error al preparar la consulta.");
}

$sentencia->bind_param("ss", $usuario, $contrasena);
$sentencia->execute();

$resultado = $sentencia->get_result();
$administrativo = $resultado->fetch_assoc();

$sentencia->close();

if ($administrativo) {

    // Guardar el usuario que inició sesión
    session_regenerate_id(true);
    $_SESSION['usuario'] = $administrativo['usuario'];

    // Ir a Administración
    header("Location: Administracion.php");
    exit();

} else {

    // Usuario o contraseña incorrectos
    header("Location: Index.html?error=1");
    exit();
}
?>
