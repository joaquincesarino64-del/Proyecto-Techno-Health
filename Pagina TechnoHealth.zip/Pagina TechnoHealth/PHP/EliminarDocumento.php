<?php
session_start();

// Comprobar que haya una sesión iniciada
if (!isset($_SESSION['usuario'])) {
    header("Location: Index.html");
    exit();
}

$iddocumentos = filter_input(INPUT_GET, 'iddocumentos', FILTER_VALIDATE_INT);

if (!$iddocumentos || $iddocumentos < 1) {
    exit("ID de documento inválido.");
}

include("bd.php");

// Eliminar el registro en la tabla intermedia 'documento_categoria'
$sql_rel = "DELETE FROM documento_categoria WHERE iddocumentos = ?";
$sentencia_rel = $conexion->prepare($sql_rel);
if ($sentencia_rel) {
    $sentencia_rel->bind_param("i", $iddocumentos);
    $sentencia_rel->execute();
    $sentencia_rel->close();
}

// Eliminar el documento de la tabla 'documentos'
$sql = "DELETE FROM documentos WHERE iddocumentos = ?";
$sentencia = $conexion->prepare($sql);

if (!$sentencia) {
    exit("Error al preparar la consulta de eliminación.");
}

$sentencia->bind_param("i", $iddocumentos);
$sentencia->execute();
$sentencia->close();

// Cerrar la conexión
$conexion->close();

// Redirigir de vuelta a la administración
header("Location: Administracion.php");
exit();
?>
