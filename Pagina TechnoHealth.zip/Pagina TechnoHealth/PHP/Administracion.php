<?php
session_start();

// Comprobar que haya una sesión iniciada
if (!isset($_SESSION['usuario'])) {
    header("Location: Index.html");
    exit();
}

// Conectar con la base de datos
include("bd.php");

// Capturar la categoría seleccionada para filtrar (si existe)
$categoria_filtro = isset($_GET['categoria']) && $_GET['categoria'] !== '' ? (int)$_GET['categoria'] : 0;

// Construir la consulta SQL dependiendo de si hay un filtro activo
if ($categoria_filtro > 0) {
    $sql = "SELECT d.iddocumentos, d.titulo, d.informacion, d.qr, d.usuario, d.FechaCreacion
            FROM documentos d
            INNER JOIN documento_categoria dc ON d.iddocumentos = dc.iddocumentos
            WHERE dc.idcategoria = ?
            ORDER BY d.iddocumentos DESC";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("i", $categoria_filtro);
    $stmt->execute();
    $resultado = $stmt->get_result();
} else {
    $sql = "SELECT iddocumentos, titulo, informacion, qr, usuario, FechaCreacion
            FROM documentos
            ORDER BY iddocumentos DESC";
    $resultado = $conexion->query($sql);
}

if (!$resultado) {
    die("Error al consultar los documentos: " . $conexion->error);
}

// Obtener las categorías para llenar la lista desplegable del filtro
$sql_categorias = "SELECT idcategoria, nombre FROM categorias ORDER BY nombre ASC";
$resultado_categorias = $conexion->query($sql_categorias);
if (!$resultado_categorias) {
    die("Error al consultar las categorías: " . $conexion->error);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administración</title>
    <link rel="stylesheet" href="Administracion.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@phosphor-icons/web@2.1.1/src/regular/style.css">

</head>
<body>
    <header class="encabezado">
        <div class="titulo">
            <span class="icono-documento">
                <i class="ph ph-key"></i>
            </span>
            <h1>Administración</h1>
        </div>
        <div class="administrador">
            <div class="circulo-usuario">
                <i class="ph ph-user"></i>
            </div>
            <div>
                <strong>Usuario Activo</strong>
                <p><?= htmlspecialchars($_SESSION['usuario'], ENT_QUOTES, 'UTF-8') ?></p>
                <p><a href="CerrarSesion.php" class="cerrar-sesion">Cerrar sesion</a></p>
            </div>
        </div>
    </header>
    <main class="contenedor">
        <section class="panel">
            <div class="cabecera-panel">
                <h2>
                    <span><i class="ph ph-folder-open"></i></span>
                    Documentos
                </h2>
                <span>Todos los documentos</span>
            </div>

            <!-- Formulario de Filtrado por Categoría -->
            <form method="GET" action="Administracion.php" class="filtro-categorias" style="margin: 20px 0; padding: 0 20px; display: flex; align-items: center; flex-wrap: wrap; gap: 10px;">
                <div>
                    <label for="categoria-select"><strong>Filtrar por Categoría:</strong></label>
                    <select id="categoria-select" name="categoria" class="form-select" style="padding: 5px; margin-left: 5px;" onchange="this.form.submit()">
                        <option value="">-- Todas las categorías --</option>
                        <?php while ($cat = $resultado_categorias->fetch_assoc()): ?>
                            <option value="<?= (int)$cat['idcategoria'] ?>" <?= ($categoria_filtro === (int)$cat['idcategoria']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($cat['nombre'], ENT_QUOTES, 'UTF-8') ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <div style="margin-left: auto; display: flex; gap: 8px;">
                    <a href="CrearCategoria.html" class="btn-crear-cat" style="padding: 6px 12px; background-color: #4b50db; color: white; text-decoration: none; border-radius: 6px; font-size: 14px; display: inline-flex; align-items: center; gap: 5px;">
                        <i class="ph ph-plus"></i> Crear Categoría
                    </a>
                    <a href="EliminarCategoria.php" class="btn-borrar-cat" style="padding: 6px 12px; background-color: #d9534f; color: white; text-decoration: none; border-radius: 6px; font-size: 14px; display: inline-flex; align-items: center; gap: 5px;">
                        <i class="ph ph-trash"></i> Borrar Categoría
                    </a>
                </div>
            </form>

            <div class="documentos">
    <?php if ($resultado->num_rows > 0): ?>
        <?php while ($documento = $resultado->fetch_assoc()): ?>
            <div class="documento">
                <!-- Enlace que cubre todo el interior de la tarjeta excepto los botones -->
                <a href="VerDocumento.php?id=<?= (int)$documento['iddocumentos'] ?>" class="documento-link">
                    <div class="icono-doc">
                        <i class="ph ph-file"></i>
                    </div>
                    <div class="nombre-documento">
                        <strong>
                            <?= htmlspecialchars($documento['titulo'], ENT_QUOTES, 'UTF-8') ?>
                        </strong>
                    </div>
                   <div class="informacion">
                        <div>
                        <small>Información</small>
                        <p><?= htmlspecialchars(mb_strimwidth($documento['informacion'], 0, 50, '...', 'UTF-8'), ENT_QUOTES, 'UTF-8') ?></p>
                        </div>
                    </div>
                    <div class="informacion">
                        <div>
                            <small>Fecha de creación/modificacion</small>
                            <p><?php if (!empty($documento['FechaCreacion'])) {
                                    echo date('d/m/Y', strtotime($documento['FechaCreacion']));
                                } else {
                                    echo 'Sin fecha';
                                }
                                ?></p>
                        </div>
                    </div>
                    <div class="informacion">
                        <div>
                            <small>Usuario</small>
                            <p><?= htmlspecialchars($documento['usuario'], ENT_QUOTES, 'UTF-8') ?></p>
                        </div>
                    </div>
                </a>

        <!-- Sección del Código QR -->
        <?php
            // Construir la URL de destino automáticamente para cada documento
            $url_destino = "http://localhost/VerDocumentoPaciente.php?id=" . (int)$documento['iddocumentos'];
            // Crear el enlace de la API con esa URL
            $qr_imagen_url = "https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=" . urlencode($url_destino);
        ?>
        <div style="padding: 0 15px;">
            <div class="admin-qr-box">
            <img src="<?= htmlspecialchars($qr_imagen_url, ENT_QUOTES, 'UTF-8') ?>" alt="QR del documento">
                <div>
                <small style="display: block; margin-bottom: 5px; color: #555;">Acceso móvil (QR)</small>
                <a href="<?= htmlspecialchars($qr_imagen_url, ENT_QUOTES, 'UTF-8') ?>&download=1" class="btn-descargar-qr" download="QR_Documento_<?= (int)$documento['iddocumentos'] ?>.png" target="_blank">
                    <i class="ph ph-download-simple"></i> Descargar QR</a>
            </div>
        </div>
    </div>
            <!-- Botones -->
            <div class="acciones">
                <a href="ModificarDocumento.php?id=<?= (int) $documento['iddocumentos'] ?>" class="btn-modificar"><i class="ph ph-pencil"></i>Modificar</a>
                <form action="EliminarDocumento.php" method="GET" onsubmit="return confirm('¿Estás seguro de que querés borrar este documento?');" style="margin: 0;">
                    <input type="hidden" name="iddocumentos" value="<?= (int) $documento['iddocumentos'] ?>">
                    <button type="submit" class="btn-borrar"><i class="ph ph-trash"></i>Borrar</button>
                </form>
            </div>
        </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p>No hay documentos registrados para esta categoría.</p>
    <?php endif; ?>
</div>
            <div class="crear-container">
                <a href="CrearDocumento.php" class="btn-crear">＋ Crear Documento</a>
            </div>
        </section>
    </main>
    <footer>
        <h2>ACCESOS DIRECTOS</h2>
        <div class="enlaces-footer">
            <p><a href="https://www.hc.edu.uy/">Página principal</a></p>
            <p><a href="Encuestas.html">Encuestas</a></p>
        </div>
    </footer>
</body>
</html>
<?php
// Cerrar las conexiones y resultados
$resultado->free();
$resultado_categorias->free();
if (isset($stmt)) {
    $stmt->close();
}
$conexion->close();
?>