<?php
include("bd.php");

// Validar que venga el ID por GET
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: Paciente.php");
    exit();
}

$id = (int)$_GET['id'];

// Consultar el documento específico
$stmt = $conexion->prepare("SELECT iddocumentos, titulo, informacion, usuario, FechaCreacion FROM documentos WHERE iddocumentos = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$resultado = $stmt->get_result();

if ($resultado->num_rows === 0) {
    die("El documento no existe.");
}

$documento = $resultado->fetch_assoc();

$stmt->close();
$conexion->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($documento['titulo'], ENT_QUOTES, 'UTF-8') ?></title>
    <link rel="stylesheet" href="VerDocumento.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@phosphor-icons/web@2.1.1/src/regular/style.css">
</head>
<body>
    <header class="encabezado">
        <div class="titulo">
            <span class="icono-documento">
                <i class="ph ph-file-text"></i>
            </span>
            <h1>Visualizador de Documento</h1>
        </div>
    </header>

    <main class="contenedor">
        <div class="hoja-documento">
            <h1 class="hoja-titulo"><?= htmlspecialchars($documento['titulo'], ENT_QUOTES, 'UTF-8') ?></h1>
            
            <div class="hoja-meta">
                <span><i class="ph ph-user"></i> <strong>Creador:</strong> <?= htmlspecialchars($documento['usuario'], ENT_QUOTES, 'UTF-8') ?></span>
                <span><i class="ph ph-calendar"></i> <strong>Fecha:</strong> <?= !empty($documento['FechaCreacion']) ? date('d/m/Y', strtotime($documento['FechaCreacion'])) : 'Sin fecha' ?></span>
            </div>

            <div class="hoja-contenido">
                <?= nl2br(htmlspecialchars($documento['informacion'], ENT_QUOTES, 'UTF-8')) ?>
            </div>

            <a href="Paciente.php" class="btn-volver">
                <i class="ph ph-arrow-left"></i> Volver a la documentacion
            </a>
        </div>
    </main>
</body>
</html>