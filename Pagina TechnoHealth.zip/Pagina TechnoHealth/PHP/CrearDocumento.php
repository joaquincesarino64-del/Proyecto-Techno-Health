<?php
session_start();

// Comprobar que haya una sesión iniciada
if (!isset($_SESSION['usuario'])) {
    header("Location: Index.html");
    exit();
}

// Conectar con la base de datos para obtener las categorías
include("bd.php");
$sql_cat = "SELECT idcategoria, nombre FROM categorias ORDER BY nombre ASC";
$resultado_cat = $conexion->query($sql_cat);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Documento</title>
    <link rel="stylesheet" href="CrearDocumento.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@phosphor-icons/web@2.1.1/src/regular/style.css">
</head>
<body>
    <header class="encabezado">
        <div class="titulo">
            <span class="icono-documento">
                <i class="ph ph-file-plus"></i>
            </span>
            <h1>Crear Documento</h1>
        </div>
    </header>

    <main class="contenedor">
        <section class="formulario">
            <div class="titulo-formulario">
                <i class="ph ph-plus-circle"></i>
                <div>
                    <h2>Nuevo documento</h2>
                    <p>Complete los datos del documento</p>
                </div>
            </div>

            <form action="SubirDocumento.php" method="POST">
                <div class="campo">
                    <label for="titulo">Título</label>
                    <input type="text" id="titulo" name="titulo" placeholder="Ingrese el título del documento" required>
                </div>

                <!-- Apartado de categorías añadido de forma estética y funcional -->
                <div class="campo">
                    <label for="idcategoria">Categoría</label>
                    <select id="idcategoria" name="idcategoria" class="form-select" style="padding: 5px; margin-left: 10px;" required>
                        <option value="">-- Seleccione una categoría --</option>
                        <?php if ($resultado_cat && $resultado_cat->num_rows > 0): ?>
                            <?php while ($cat = $resultado_cat->fetch_assoc()): ?>
                                <option value="<?= (int)$cat['idcategoria'] ?>">
                                    <?= htmlspecialchars($cat['nombre'], ENT_QUOTES, 'UTF-8') ?>
                                </option>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </select>
                </div>

                <div class="campo">
                    <label for="informacion">Información</label>
                    <textarea id="informacion" name="informacion" placeholder="Escriba la información del documento" required></textarea>
                </div>

                <div class="accion-formulario">
                    <a href="Administracion.php" class="btn-cancelar">Cancelar</a>
                    <button type="submit" class="btn-subir">
                        <i class="ph ph-upload-simple"></i> Subir Documento
                    </button>
                </div>
            </form>
        </section>
    </main>

    <footer>
        <h2>ACCESOS DIRECTOS</h2>
        <div class="enlaces-footer">
            <p><a href="https://www.hc.edu.uy/">Página principal</a></p>
            <p><a href="Encuestas.html">Encuestas</a></p>
        </div>
    </footer>
</body>
</html>
<?php
if ($resultado_cat) {
    $resultado_cat->free();
}
$conexion->close();
?>