<?php
session_start();

// Comprobar que haya una sesión iniciada
if (!isset($_SESSION['usuario'])) {
    header("Location: Index.html");
    exit();
}

include("bd.php");

$mensaje = "";

// Si se envió el formulario para borrar
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $idcategoria = isset($_POST['idcategoria']) ? (int)$_POST['idcategoria'] : 0;

    if ($idcategoria > 0) {
        // Eliminar las relaciones en la tabla intermedia 'documento_categoria' 
        $sql_rel = "DELETE FROM documento_categoria WHERE idcategoria = ?";
        $stmt_rel = $conexion->prepare($sql_rel);
        if ($stmt_rel) {
            $stmt_rel->bind_param("i", $idcategoria);
            $stmt_rel->execute();
            $stmt_rel->close();
        }

        // Eliminar la categoría de la tabla 'categorias'
        $sql_cat = "DELETE FROM categorias WHERE idcategoria = ?";
        $stmt_cat = $conexion->prepare($sql_cat);
        if ($stmt_cat) {
            $stmt_cat->bind_param("i", $idcategoria);
            if ($stmt_cat->execute()) {
                $stmt_cat->close();
                $conexion->close();
                // Redirigir de vuelta a la administración tras el éxito
                header("Location: Administracion.php");
                exit();
            } else {
                $mensaje = "Error al intentar borrar la categoría.";
            }
            $stmt_cat->close();
        }
    } else {
        $mensaje = "Por favor, seleccione una categoría válida.";
    }
}

// Obtener todas las categorías para listarlas en el selector
$sql_categorias = "SELECT idcategoria, nombre FROM categorias ORDER BY nombre ASC";
$resultado_categorias = $conexion->query($sql_categorias);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Borrar Categoría</title>
    <link rel="stylesheet" href="CrearDocumento.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@phosphor-icons/web@2.1.1/src/regular/style.css">
</head>
<body>
    <header class="encabezado">
        <div class="titulo">
            <span class="icono-documento">
                <i class="ph ph-trash"></i>
            </span>
            <h1>Eliminar Categoría</h1>
        </div>
    </header>

    <main class="contenedor">
        <section class="formulario">
            <div class="titulo-formulario">
                <i class="ph ph-warning-circle" style="color: #d9534f;"></i>
                <div>
                    <h2>Eliminar Categoría</h2>
                    <p>Seleccione la categoría que desea borrar permanentemente</p>
                </div>
            </div>

            <?php if ($mensaje !== ""): ?>
                <p style="color: red; margin-bottom: 15px; font-weight: bold;"><?php echo htmlspecialchars($mensaje, ENT_QUOTES, 'UTF-8'); ?></p>
            <?php endif; ?>

            <form action="EliminarCategoria.php" method="POST" onsubmit="return confirm('¿Estás seguro de que deseas borrar esta categoría? Se desvincularán los documentos asociados.');">
                
                <div class="campo">
                    <label for="idcategoria">Categoría a eliminar</label>
                    <select id="idcategoria" name="idcategoria" required>
                        <option value="">-- Seleccione una categoría --</option>
                        <?php if ($resultado_categorias && $resultado_categorias->num_rows > 0): ?>
                            <?php while ($cat = $resultado_categorias->fetch_assoc()): ?>
                                <option value="<?= (int)$cat['idcategoria'] ?>">
                                    <?= htmlspecialchars($cat['nombre'], ENT_QUOTES, 'UTF-8') ?>
                                </option>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </select>
                </div>

                <div class="accion-formulario">
                    <a href="Administracion.php" class="btn-cancelar">Cancelar</a>
                    <button type="submit" class="btn-subir" style="background: linear-gradient(90deg, #d9534f, #c9302c); border-color: #ac2925;">
                        <i class="ph ph-trash"></i> Borrar Categoría
                    </button>
                </div>

            </form>
        </section>
    </main>

    <footer>
        <h2>ACCESOS DIRECTOS</h2>
        <div class="enlaces-footer">
            <p><a href="https://www.hc.edu.uy/">Página principal</a></p>
            <p><a href="Encuestas.html">Encuestas</a></p>
        </div>
    </footer>
</body>
</html>
<?php
if ($resultado_categorias) {
    $resultado_categorias->free();
}
$conexion->close();
?>