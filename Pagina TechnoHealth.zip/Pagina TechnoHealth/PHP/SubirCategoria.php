<?php
session_start();

// Comprobar que haya una sesión iniciada
if (!isset($_SESSION['usuario'])) {
    header("Location: Index.html");
    exit();
}

// Comprobar que los datos se hayan enviado mediante POST
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: CrearCategoria.html");
    exit();
}

$nombreCategoria = trim($_POST['nombre'] ?? '');

if ($nombreCategoria === '') {
    exit("Error: El nombre de la categoría no puede estar vacío.");
}

// Conectar con la base de datos
include("bd.php");

// Insertar la nueva categoría en la tabla 'categorias'
$sql = "INSERT INTO categorias (nombre) VALUES (?)";
$sentencia = $conexion->prepare($sql);

if (!$sentencia) {
    exit("Error al preparar la consulta.");
}

$sentencia->bind_param("s", $nombreCategoria);

if ($sentencia->execute()) {
    $sentencia->close();
    $conexion->close();

    // Redirigir de vuelta a la administración
    header("Location: Administracion.php");
    exit();
} else {
    echo "Error al guardar la categoría: " . $conexion->error;
}

$sentencia->close();
$conexion->close();
?>