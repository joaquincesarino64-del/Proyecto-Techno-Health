<?php
session_start();

// Comprobar que haya una sesión iniciada
if (!isset($_SESSION['usuario'])) {
    header("Location: Index.html");
    exit();
}

// Comprobar que los datos se hayan enviado mediante POST
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: CrearDocumento.php");
    exit();
}

// Obtener los datos del formulario (incluyendo la categoría)
$titulo = trim($_POST['titulo'] ?? '');
$informacion = trim($_POST['informacion'] ?? '');
$idcategoria = isset($_POST['idcategoria']) ? (int)$_POST['idcategoria'] : 0;

// Generar la fecha de creación automáticamente con la fecha actual del servidor
$FechaCreacion = (new DateTimeImmutable('today'))->format('Y-m-d');

// Obtener el usuario de la sesión
$usuario = $_SESSION['usuario'];

// Validar los campos obligatorios
if ($titulo === '' || $informacion === '' || $idcategoria <= 0) {
    exit("Error: todos los campos obligatorios y la categoría deben estar completos.");
}

// Conectar con la base de datos
include("bd.php");

$qr = "";

// Insertar el documento en la tabla 'documentos'
$sql = "INSERT INTO documentos
        (titulo, informacion, qr, usuario, FechaCreacion)
        VALUES (?, ?, ?, ?, ?)";

$sentencia = $conexion->prepare($sql);

if (!$sentencia) {
    exit("Error al preparar la consulta del documento.");
}

$sentencia->bind_param(
    "sssss",
    $titulo,
    $informacion,
    $qr,
    $usuario,
    $FechaCreacion
);

// Ejecutar la consulta del documento
if ($sentencia->execute()) {
    // Obtener el ID del documento que se acaba de insertar
    $iddocumentos = $conexion->insert_id;
    $sentencia->close();
    
    // Construir la URL exacta a la que apuntará el QR
    $url_destino = "http://localhost/VerDocumentoPaciente.php?id=" . $iddocumentos;

    // 3. Generar la URL de la API del QR y guardarla en la BD
    $qr_imagen_url = "https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=" . urlencode($url_destino);

    $sql_update_qr = "UPDATE documentos SET qr = ? WHERE iddocumentos = ?";
    $stmt_qr = $conexion->prepare($sql_update_qr);
    if ($stmt_qr) {
        $stmt_qr->bind_param("si", $qr_imagen_url, $iddocumentos);
        $stmt_qr->execute();
        $stmt_qr->close();
    }

    // Insertar la relación en la tabla 'documento_categoria'
    $sql_relacion = "INSERT INTO documento_categoria (iddocumentos, idcategoria) VALUES (?, ?)";
    $sentencia_relacion = $conexion->prepare($sql_relacion);

    if ($sentencia_relacion) {
        $sentencia_relacion->bind_param("ii", $iddocumentos, $idcategoria);
        $sentencia_relacion->execute();
        $sentencia_relacion->close();
    }

    $conexion->close();

    // Redirigir a la página de administración
    header("Location: Administracion.php");
    exit();
} else {
    echo "Error al guardar el documento.";
}

// Cerrar conexiones en caso de fallo
$sentencia->close();
$conexion->close();
?>