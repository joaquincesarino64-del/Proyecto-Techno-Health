<?php
session_start();

// Comprobar que haya una sesión iniciada
if (!isset($_SESSION['usuario'])) {
    header("Location: Index.html");
    exit();
}

include("bd.php");

// Obtener el ID del documento seleccionado
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id = filter_input(INPUT_POST, "iddocumentos", FILTER_VALIDATE_INT);
} else {
    $id = filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT);
}

if (!$id || $id < 1) {
    exit("No se seleccionó un documento válido.");
}

$error = "";

// Si se envió el formulario, guardar los cambios
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $titulo = trim($_POST["titulo"] ?? "");
    $informacion = trim($_POST["informacion"] ?? "");
    $idcategoria = isset($_POST['idcategoria']) ? (int)$_POST['idcategoria'] : 0;

    // Generar la fecha de creación/modificación automáticamente con la fecha actual del servidor
    $FechaCreacion = (new DateTimeImmutable('today'))->format('Y-m-d');
    
    // Tomamos el usuario directamente de la sesión activa
    $usuario = $_SESSION['usuario'];

    if ($titulo === "" || $informacion === "" || $idcategoria <= 0) {

        $error = "Todos los campos son obligatorios y debe seleccionar una categoría.";

    } else {

        // 1. Actualizamos título, información, fecha y usuario en la tabla documentos
        $sql = "UPDATE documentos
                SET titulo = ?,
                    informacion = ?,
                    FechaCreacion = ?,
                    usuario = ?
                WHERE iddocumentos = ?";

        $stmt = $conexion->prepare($sql);

        if (!$stmt) {
            exit("Error al preparar la consulta de actualización.");
        }

        $stmt->bind_param(
            "ssssi",
            $titulo,
            $informacion,
            $FechaCreacion,
            $usuario,
            $id
        );

        if ($stmt->execute()) {
            $stmt->close();

            // 2. Actualizar la categoría en la tabla intermedia documento_categoria
            // Primero eliminamos la relación anterior (si existe) para evitar duplicados
            $sql_del = "DELETE FROM documento_categoria WHERE iddocumentos = ?";
            $stmt_del = $conexion->prepare($sql_del);
            if ($stmt_del) {
                $stmt_del->bind_param("i", $id);
                $stmt_del->execute();
                $stmt_del->close();
            }

            // Insertamos la nueva categoría seleccionada
            $sql_rel = "INSERT INTO documento_categoria (iddocumentos, idcategoria) VALUES (?, ?)";
            $stmt_rel = $conexion->prepare($sql_rel);
            if ($stmt_rel) {
                $stmt_rel->bind_param("ii", $id, $idcategoria);
                $stmt_rel->execute();
                $stmt_rel->close();
            }

            $conexion->close();

            header("Location: Administracion.php");
            exit;
        } else {
            $error = "No se pudieron modificar los datos.";
        }

        $stmt->close();
    }
}

// Buscar el documento que se va a modificar
$sql = "SELECT iddocumentos, titulo, informacion, usuario, FechaCreacion
        FROM documentos
        WHERE iddocumentos = ?";

$stmt = $conexion->prepare($sql);

if (!$stmt) {
    exit("Error al preparar la consulta de búsqueda.");
}

$stmt->bind_param("i", $id);
$stmt->execute();
$resultado = $stmt->get_result();
$documento = $resultado->fetch_assoc();
$stmt->close();

if (!$documento) {
    exit("El documento seleccionado no existe.");
}

// Obtener la categoría actual asignada al documento
$sql_cat_doc = "SELECT idcategoria FROM documento_categoria WHERE iddocumentos = ?";
$stmt_cat_doc = $conexion->prepare($sql_cat_doc);
$stmt_cat_doc->bind_param("i", $id);
$stmt_cat_doc->execute();
$res_cat_doc = $stmt_cat_doc->get_result();
$categoria_actual = 0;
if ($row_cat = $res_cat_doc->fetch_assoc()) {
    $categoria_actual = (int)$row_cat['idcategoria'];
}
$stmt_cat_doc->close();

// Obtener todas las categorías disponibles para llenar la lista desplegable
$sql_categorias = "SELECT idcategoria, nombre FROM categorias ORDER BY nombre ASC";
$resultado_categorias = $conexion->query($sql_categorias);

// Mostrar los datos de forma segura
function escapar($valor) {
    return htmlspecialchars(
        (string)($valor ?? ""),
        ENT_QUOTES,
        "UTF-8"
    );
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar Documento</title>
    <link rel="stylesheet" href="CrearDocumento.css">
    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/@phosphor-icons/web@2.1.1/src/regular/style.css">
</head>

<body>

    <header class="encabezado">
        <div class="titulo">
            <span class="icono-documento">
                <i class="ph ph-clock-clockwise"></i>
            </span>
            <h1>Modificar Documento</h1>
        </div>
    </header>

    <main class="contenedor">
        <section class="formulario">

            <div class="titulo-formulario">
                <i class="ph ph-arrows-clockwise"></i>
                <div>
                    <h2>Modificar</h2>
                </div>
            </div>

            <?php if ($error !== ""): ?>
                <p style="color: red; margin-bottom: 15px;"><?php echo escapar($error); ?></p>
            <?php endif; ?>

            <form action="ModificarDocumento.php" method="POST">
                
                <div class="campo">
                    <label for="iddocumentos">ID Documento</label>
                    <input type="number" id="iddocumentos" name="iddocumentos" value="<?php echo escapar($documento['iddocumentos']); ?>" readonly>
                    <small>*Número identificador del documento, no se puede cambiar*</small>
                </div>

                <div class="campo">
                    <label for="titulo">Título</label>
                    <input type="text" id="titulo" name="titulo" placeholder="Ingrese el título del documento" value="<?php echo escapar($documento['titulo']); ?>" required>
                </div>

                <!-- Campo de Categoría desplegable -->
                <div class="campo">
                    <label for="idcategoria">Categoría</label>
                    <select id="idcategoria" name="idcategoria" class="form-select" style="padding: 5px; margin-left: 10px;" required>
                        <option value="">-- Seleccione una categoría --</option>
                        <?php if ($resultado_categorias && $resultado_categorias->num_rows > 0): ?>
                            <?php while ($cat = $resultado_categorias->fetch_assoc()): ?>
                                <option value="<?= (int)$cat['idcategoria'] ?>" <?= ($categoria_actual === (int)$cat['idcategoria']) ? 'selected' : '' ?>>
                                    <?= escapar($cat['nombre']) ?>
                                </option>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </select>
                </div>

                <div class="campo">
                    <label for="informacion">Información</label>
                    <textarea id="informacion" name="informacion" placeholder="Escriba la información del documento" rows="5" required><?php echo escapar($documento['informacion']); ?></textarea>
                </div>

                <div class="accion-formulario">
                    <a href="Administracion.php" class="btn-cancelar">Cancelar</a>
                    <button type="submit" class="btn-subir">
                        <i class="ph ph-upload-simple"></i>Modificar Documento</button>
                </div>

            </form>
        </section>
    </main>

    <footer>
        <h2>ACCESOS DIRECTOS</h2>
        <div class="enlaces-footer">
            <a href="https://www.hc.edu.uy/">Página principal</a>
            <a href="Encuestas.html">Encuestas</a>
        </div>
    </footer>

</body>
</html>
<?php
if ($resultado_categorias) {
    $resultado_categorias->free();
}
$conexion->close();
?>