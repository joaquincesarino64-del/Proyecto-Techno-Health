<?php
$host="localhost";
$usuario2="root";
$contra="";
$bd="bd";
// Crear conexion
$conexion = new mysqli($host,$usuario2,$contra,$bd);
// Verificar conexion
if($conexion->connect_errno){
    die("error con la conexion: ".$conexion->connect_errno);
}
?>